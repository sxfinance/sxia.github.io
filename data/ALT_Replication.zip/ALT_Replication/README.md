## Optimal soda tax repository

This is the full replication file for Allcott, Lockwood, and Taubinsky: Regressive Sin Taxes, with an Application to the Optimal Soda Tax
To replicate the pdf of this paper from scratch:
1. Unzip this folder to your computer.
2. Set up software as instructed here: https://github.com/huntallcott/lab/wiki/Setup
3. Put data into Externals/Data folders in the proper folder. (Due to legal restrictions, we cannot publicly post the Nielsen data.)
4. Run MakePaper.py