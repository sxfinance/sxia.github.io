function alpha = compute_pareto_weights(prim,eqbm)

% Return stored exogenous Pareto weights
alpha = prim.paretoWts;

end
