# Input data Readme

* beta_vs_income.pdf
	* This file is created from the plot in the spreadsheet `/dropbox/data/input/Notes on beta estimates.xlsx`.