function simulations()
% Compute optimal tax rates using a fixed point iteration

global e tUS DROPBOX FIGDIR DATADIR nu SPEC blue red;

github = '../../../github/';
DROPBOX = '../../../dropbox/';

FIGDIR = [github 'analysis/output/figures/'];
DATADIR = [DROPBOX 'data/'];

% define colors and graphical parameters
red = [0.8 0 0];
blue = [0 0 1];
fontsize = 14;

specs = {   'with_goda'
            'low_phi'
            'const_beta'
            'lowelast'
            'highelast'
            'crra'
            ''
         };

for iSpec = 1:length(specs)
         
    SPEC = specs{iSpec}
    
    
    wwBot = 1.1;
    wwMed = 1;
    wwTop = .6;
    
    nu = 1; % curvature parameter on CRRA utility (1 is like log utility)
    
    shareDis = 0.02;
    incDis = 7.5; % estimate of avg SSI income from CPS
    revReq = 5 + shareDis*incDis; % approximate required revenue
    
    
    e = 0.3;
    switch SPEC
        case 'highelast'
            e = 0.4;
        case 'lowelast'
            e = 0.2;
    end
    
    
    [zGridUS,mtrUS,mtr2ch,incdensUS,ftshareUS] = load_cps_data();
    
    [zSteuerle,mtrSteuerle] = load_steuerle_mtrs();
    
    % Construct discretized pmf
    cdf_cps = incdensUS(1) + cumtrapz(zGridUS,incdensUS);
    dz = diff(zGridUS);
    zBucketSize = [dz(1); dz]; % suppose bucket width is same size for 0 bucket
    
    % zGrid is log-spaced for higher values, so tack on more points at similar log spacing
    zN = length(zGridUS);
    extendBy = 30;
    zUpperTailLog = interp1((1:zN)',log(zGridUS),(zN+1:zN+extendBy)','linear','extrap');
    zFull = [zGridUS; exp(zUpperTailLog)]; % income grid
    
    cdfLo = [cdf_cps; nan(extendBy-1,1)];
    pIdx = find(cdf_cps > 0.86,1);
    % pIdx = find(cdf_cps > 0.95,1);
    pTail = 2;
    
    xm = fsolve(@(x) cdf_cps(pIdx) - pcdf(zFull(pIdx),pTail,x*1000),25)*1000;
    zMP = (zFull(1:end-1)+zFull(2:end))/2;
    cdfHi = pcdf(zMP,pTail,xm);
    
    pmfLo = diff([0; cdfLo]);
    pmfLo(isnan(pmfLo)) = 0;
    pmfHi = diff([0; cdfHi]);
    
    nTrans = 30; % length of transition
    iTrans = pIdx-nTrans/2; % start smooth pasting
    trans = [zeros(iTrans,1); linspace(0,1,nTrans)'; ones(length(pmfLo)-iTrans-nTrans,1)]; % smooth
    pmf = (1-trans).*pmfLo + trans.*pmfHi;
    z = (zFull(1:end-1)+zFull(2:end))/2; % midpoints
    
    % raise minimum earnings if desired
    if strcmp(SPEC,'posmin')
        iStart = find(z > 5000,1);
        pmf = [0; pmf(iStart:end)];
        z = [0; z(iStart:end)];
    end
    
    pmf = pmf./(sum(pmf));
    cdf = cumsum(pmf);
    
    
    % for display and numerics below
    scale = 1e-3;
    z = z*scale;
    zGridUS = zGridUS*scale;
    
    % specify bias (drawn from calibrations in paper)
    b = interp1([0 85.98075782 1000],[0.438958402 1 1],z,'linear','extrap');
    
    switch SPEC
        case 'const_beta'
            b = ones(size(b))*pmf'*b; % constant beta in this case
        case 'with_goda'
            b = interp1([0 175.8391512 1000],[0.591734207 1 1],z,'linear','extrap');
    end
    
    
    N = length(z);
    taxUSsmooth = interp1(zGridUS,mtrUS,z,'linear','extrap');
    idx = find(z > 150,1);
    taxUSsmooth(idx:end) = taxUSsmooth(idx);
    tUS = taxUSsmooth(1:end-1);
    grantUS = 1;
    
    wBeh = [0; (z(2:end).*(1-tUS).^(-e)).^(1./(1+e))];
    % this is a fn of w and b -- it's a sufficient statistic for behavior
    
    wWelf = wBeh.*b.^(-(e/(1+e)));
    % this is _true_ ability, which is relevant for welfare calculations
    
    
    iters = 500;
    zMat = nan(N,iters);
    tMat = nan(N-1,iters);
    
    elast_c = e;
    
    plot(z(2:end),elast_c), xlim([0 150])
    
    
    % plot existing tax
    h1 = plot(zSteuerle/1000,mtrSteuerle,'o');
    set(h1,'Color',[0.5 0.5 0.5],'MarkerFaceColor',[0.5 0.5 0.5],'MarkerSize',3);
    ylabel('Marginal tax rate');
    xlabel('Household income ($1000s)');
    
    % plot horiz line at zero
    hold on;
    plot([-10 1000],[0 0],'k-');
    hold off;
    
    % set mswws (linear interpolation)
    msww = interp1([0 0.5 1],[wwBot wwMed wwTop],cumsum(pmf),'linear','extrap');
    msww = msww/(msww'*pmf);
    
    % Impose constraint to ensure consumption doesn't become negative at bottom incomes.
    if strcmp(SPEC,'highelast')
        msww = msww*.9978;
    end
    
    % seed starting point
    t = tUS;
    g = grantUS;
    
    tStep = 0.05;
    
    iter = 1;
    zMat(:,iter) = z;
    tMat(:,iter) = t;
    
    % Compute optimal taxes without present bias
    while iter < iters
        iter = iter+1;
        
        % Step 1: compute welfare weights taking tax as given
        T = compute_tax_paid(t,z,g);
        c = z - T;
        
        if strcmp(SPEC,'crra')
            welf = c - (z./wBeh).^(1+1/e)./(1+1/e);
            welf(1) = c(1);
            muc = 1e100*ones(size(welf));
            muc(welf > 0) = welf(welf > 0).^(-nu);
            msww = muc/(muc'*pmf);
        end
        
        
        % Step 2: compute optimal tax
        dz = diff(z);
        mswwAbove = zeros(N-1,1);
        for j=2:N
            mswwAbove(j-1) = sum((1 - msww(j:end)).*pmf(j:end));
        end
        
        keepshare = dz./(pmf(2:end).*z(2:end).*elast_c).*mswwAbove;
        tNew = keepshare./(1+keepshare);
        
        t = tStep*tNew + (1-tStep)*t;
        
        % Step 3: compute new grant, raising or lowering by gov't surplus or deficit
        T = compute_tax_paid(t,z,g) - revReq;
        g = g + pmf'*T;
        
        % Step 4: compute new income distribution
        z = compute_income_dist(t,wBeh,elast_c);
        
        zMat(:,iter) = z;
        tMat(:,iter) = t;
        
    end
    
    % store results
    g_no_eitc = g;
    welfare_no_eitc = (c(2:end) - (z(2:end)./wWelf(2:end)).^(1+1/e)./(1+1/e));
    welfare_no_eitc_nobias = (c(2:end) - (z(2:end)./wBeh(2:end)).^(1+1/e)./(1+1/e));
    z_no_eitc = z;
    c_no_eitc = c;
    t_no_eitc = t;
    
    legend('Effective net MTRs','US statutory fed. tax rates','Location','NorthEast');
    
    set(gca,'FontSize',fontsize);
    
    hold on;
    zMP = (z(1:end-1)+z(2:end))/2;
    h2 = plot(zMP(zMP>.05),100*t(zMP>.05),'Color',blue); % exclude extreme rates on lowest earners
    
    set(h2,'LineWidth',2);
    hold off;
    legend([h1 h2],{'Effective net MTRs','Rational optimum'});
    
    iter = 1;
    zMat(:,iter) = z;
    tMat(:,iter) = t;
    tStep = 0.005;
    
    g = grantUS;
    iters = 1000;
    
    % Compute optimal taxes with present bias
    
    switch SPEC
        case 'low_phi'
            phi = 0.5;
        otherwise
            phi = 1;
    end
    
    while iter < iters
        iter = iter+1;
        
        % Step 1: compute welfare weights taking tax as given
        T = compute_tax_paid(t,z,g);
        c = z - T;
        
        if strcmp(SPEC,'crra')
            welf = c - (z./wWelf).^(1+1/e)./(1+1/e);
            welf(1) = c(1);
            muc = 1e100*ones(size(welf));
            muc(welf > 0) = welf(welf > 0).^(-nu);
            msww = muc/(muc'*pmf);
        end
        
        % Step 2: compute optimal tax
        dz = diff(z);
        
        mswwAbove = zeros(N-1,1);
        for j=2:N
            mswwAbove(j-1) = sum((1 - msww(j:end)).*pmf(j:end));
        end
        
        keepshare = dz./(pmf(2:end).*z(2:end).*elast_c).*mswwAbove - msww(2:end).*phi.*(1-b(2:end));
        
        % keepshare < -1 is undefined, so constrain to prevent this from happening during
        % optimization. Check that it doesn't bind at optimum in the end.
        keepshare(keepshare < -0.99) = -0.99;
        
        tNew = keepshare./(1+keepshare);
        t = tStep*tNew + (1-tStep)*t;
        
        % Step 3: compute new grant, raising or lowering by gov't surplus or deficit
        T = compute_tax_paid(t,z,g) - revReq;
        g = g + pmf'*T;
        
        % Step 4: compute new income distribution
        z = compute_income_dist(t,wBeh,elast_c);
        
        zMat(:,iter) = z;
        tMat(:,iter) = t;
        
    end
    
    % store results
    g_with_eitc = g;
    welfare_with_eitc = (c(2:end) - (z(2:end)./wWelf(2:end)).^(1+1/e)./(1+1/e));
    welfare_with_eitc_nobias = (c(2:end) - (z(2:end)./wBeh(2:end)).^(1+1/e)./(1+1/e));
    z_with_eitc = z;
    c_with_eitc = c;
    t_with_eitc = t;
    
    xlim([0 100]); ylim([-40 80]);
    
    hold on;
    zMP = (z(1:end-1)+z(2:end))/2;
    h3 = plot(zMP(zMP>.05),100*t(zMP>.05),'Color',red);
    set(h3,'LineWidth',2,'LineStyle','--');
    hold off;
    legend([h2 h3 h1],{'Rational optimum','Present-biased optimum','US net tax rates'},'Location','SouthEast');
    % xlim([0 150]); ylim([-30 70]);
    
    switch SPEC
        case 'crra'
            save([DROPBOX 'data/intermediate/calib_log.mat']);
        case 'highelast'
            save([DROPBOX 'data/intermediate/calib_highelast.mat']);
        case 'lowelast'
            save([DROPBOX 'data/intermediate/calib_lowelast.mat']);
        case 'const_beta'
            save([DROPBOX 'data/intermediate/calib_const_beta.mat']);
        case 'low_phi'
            save([DROPBOX 'data/intermediate/calib_low_phi.mat']);
        case 'with_goda'
            saveTightFigure(gcf,[FIGDIR 'opt_tax_sims_with_goda']);
        otherwise
            saveTightFigure(gcf,[FIGDIR 'opt_tax_sims']);
            save([DROPBOX 'data/intermediate/calib_baseline.mat']);
    end
end

disp('lump sum grants:');
g_with_eitc
g_no_eitc

disp('population average beta (mentioned in text):');
pmf'*b

disp('welfare increase (at optimum) from accounting for bias, in dollars:')
(welfare_with_eitc' - welfare_no_eitc')*(msww(2:end).*pmf(2:end))/scale

disp('as percentage of aggregate consumption:')
100*(welfare_with_eitc' - welfare_no_eitc')*(msww(2:end).*pmf(2:end))/(c_with_eitc'*pmf)

disp('as percentage of median consumption:')
med_idx = find(cdf>.5,1);
100*(welfare_with_eitc' - welfare_no_eitc')*(msww(2:end).*pmf(2:end))/(c_with_eitc(med_idx))

switch SPEC
    case ''
        plot_specs();
end

end


function plot_specs()
    global red blue FIGDIR DROPBOX;
    fontsize = 12;
    
    hFig = figure(1);

    subplot(3,2,1);
    load([DROPBOX 'data/intermediate/calib_baseline.mat'],'t_no_eitc','z_no_eitc','t_with_eitc','z_with_eitc');
    zMPn = (z_no_eitc(1:end-1)+z_no_eitc(2:end))/2;
    zMPb = (z_with_eitc(1:end-1)+z_with_eitc(2:end))/2;
    h = plot(zMPn(zMPn>.5),t_no_eitc(zMPn>.5),'-',zMPb(zMPb>.5),t_with_eitc(zMPb>.5),'--',[0 500],[0 0],'-');
    set(h(1:2),'LineWidth',2); set(h(3),'LineWidth',.5,'Color','k');
    set(h(1),'Color',blue); set(h(2),'Color',red);
    xlim([0 150]); ylim([-0.5 1]);
    title('(a) Baseline');
    ylabel('Marginal tax rate');
    legend('Rational optimum','Present-biased optimum');
    set(gca,'FontSize',fontsize);
    
    subplot(3,2,2);
    load([DROPBOX 'data/intermediate/calib_log.mat'],'t_no_eitc','z_no_eitc','t_with_eitc','z_with_eitc');
    zMPn = (z_no_eitc(1:end-1)+z_no_eitc(2:end))/2;
    zMPb = (z_with_eitc(1:end-1)+z_with_eitc(2:end))/2;
    h = plot(zMPn(zMPn>.5),t_no_eitc(zMPn>.5),'-',zMPb(zMPb>.5),t_with_eitc(zMPb>.5),'--',[0 500],[0 0],'-');
    set(h(1:2),'LineWidth',2); set(h(3),'LineWidth',.5,'Color','k');
    set(h(1),'Color',blue); set(h(2),'Color',red);
    xlim([0 150]); ylim([-0.5 1]);
    title('(b) Log redistributive tastes');
    set(gca,'FontSize',fontsize);
    
    subplot(3,2,3);
    load([DROPBOX 'data/intermediate/calib_highelast.mat'],'t_no_eitc','z_no_eitc','t_with_eitc','z_with_eitc');
    zMPn = (z_no_eitc(1:end-1)+z_no_eitc(2:end))/2;
    zMPb = (z_with_eitc(1:end-1)+z_with_eitc(2:end))/2;
    h = plot(zMPn(zMPn>.5),t_no_eitc(zMPn>.5),'-',zMPb(zMPb>.5),t_with_eitc(zMPb>.5),'--',[0 500],[0 0],'-');
    set(h(1:2),'LineWidth',2); set(h(3),'LineWidth',.5,'Color','k');
    set(h(1),'Color',blue); set(h(2),'Color',red);
    xlim([0 150]); ylim([-0.5 1]);
    title('(c) High elasticity (0.4)');
    ylabel('Marginal tax rate');
    set(gca,'FontSize',fontsize);
   
    subplot(3,2,4);
    load([DROPBOX 'data/intermediate/calib_lowelast.mat'],'t_no_eitc','z_no_eitc','t_with_eitc','z_with_eitc');
    zMPn = (z_no_eitc(1:end-1)+z_no_eitc(2:end))/2;
    zMPb = (z_with_eitc(1:end-1)+z_with_eitc(2:end))/2;
    h = plot(zMPn(zMPn>.5),t_no_eitc(zMPn>.5),'-',zMPb(zMPb>.5),t_with_eitc(zMPb>.5),'--',[0 500],[0 0],'-');
    set(h(1:2),'LineWidth',2); set(h(3),'LineWidth',.5,'Color','k');
    set(h(1),'Color',blue); set(h(2),'Color',red);
    xlim([0 150]); ylim([-0.5 1]);
    title('(d) Low elasticity (0.2)');
    set(gca,'FontSize',fontsize);
    
    subplot(3,2,5);
    load([DROPBOX 'data/intermediate/calib_const_beta.mat'],'t_no_eitc','z_no_eitc','t_with_eitc','z_with_eitc');
    zMPn = (z_no_eitc(1:end-1)+z_no_eitc(2:end))/2;
    zMPb = (z_with_eitc(1:end-1)+z_with_eitc(2:end))/2;
    h = plot(zMPn(zMPn>.5),t_no_eitc(zMPn>.5),'-',zMPb(zMPb>.5),t_with_eitc(zMPb>.5),'--',[0 500],[0 0],'-');
    set(h(1:2),'LineWidth',2); set(h(3),'LineWidth',.5,'Color','k');
    set(h(1),'Color',blue); set(h(2),'Color',red);
    xlim([0 150]); ylim([-0.5 1]);
    title('(e) Constant \beta');
    xlabel('Market income ($1000s)');
    ylabel('Marginal tax rate');
    set(gca,'FontSize',fontsize);

    subplot(3,2,6);
    load([DROPBOX 'data/intermediate/calib_low_phi.mat'],'t_no_eitc','z_no_eitc','t_with_eitc','z_with_eitc');
    zMPn = (z_no_eitc(1:end-1)+z_no_eitc(2:end))/2;
    zMPb = (z_with_eitc(1:end-1)+z_with_eitc(2:end))/2;
    h = plot(zMPn(zMPn>.5),t_no_eitc(zMPn>.5),'-',zMPb(zMPb>.5),t_with_eitc(zMPb>.5),'--',[0 500],[0 0],'-');
    set(h(1:2),'LineWidth',2); set(h(3),'LineWidth',.5,'Color','k');
    set(h(1),'Color',blue); set(h(2),'Color',red);
    xlim([0 150]); ylim([-0.5 1]);
    title('(f) Half of labor supply unbiased');
    xlabel('Market income ($1000s)');
    set(gca,'FontSize',fontsize);
    
    set(hFig, 'Position', [100 100 560 650]);
    
    printpdf(gcf,[FIGDIR 'full_sims.pdf']);
    close;
end

function printpdf(h,outfilename)

set(h, 'PaperUnits','centimeters');
set(h, 'Units','centimeters');
pos=get(h,'Position');
set(h, 'PaperSize', [pos(3) pos(4)]);
set(h, 'PaperPositionMode', 'manual');
set(h, 'PaperPosition',[0 0 pos(3) pos(4)]);
print('-dpdf',outfilename);

end

function T = compute_tax_paid(t,z,grant)
T = zeros(size(z));
T(1) = -grant;
for i=1:length(t)
    T(1+i) = T(i) + t(i)*(z(i+1)-z(i));
end
end


function z = compute_income_dist(t,w,e)
% Find the labor supply as a function of 
z = zeros(size(w));
z(2:end) = w(2:end).^(1+e).*(1-t).^e;
end


function F = pcdf(x,a,xm)
F = gpcdf(x,1./a,xm./a,xm);
end


function [zGridUS,mtrUS,mtr2ch,incdens,ftshare] = load_cps_data()
% Import data saved from Stata

global DATADIR;
filename = [DATADIR 'intermediate/cpsdata.csv'];
delimiter = ',';
startRow = 2;
endRow = inf;

formatSpec = '%f%f%f%f%f%[^\n\r]';
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, endRow(1)-startRow(1)+1, 'Delimiter', delimiter, 'HeaderLines', startRow(1)-1, 'ReturnOnError', false);
for block=2:length(startRow)
    frewind(fileID);
    dataArrayBlock = textscan(fileID, formatSpec, endRow(block)-startRow(block)+1, 'Delimiter', delimiter, 'HeaderLines', startRow(block)-1, 'ReturnOnError', false);
    for col=1:length(dataArray)
        dataArray{col} = [dataArray{col};dataArrayBlock{col}];
    end
end

fclose(fileID);
zGridUS = dataArray{:, 1};
mtrUS = dataArray{:, 2};
mtr2ch = dataArray{:, 3};
incdens = dataArray{:, 4};
ftshare = dataArray{:, 5};
end


function saveTightFigure(h,outfilename)
% SAVETIGHTFIGURE(H,OUTFILENAME) Saves figure H in file OUTFILENAME without
%   the white space around it.
%
% by ``a grad student"
% http://tipstrickshowtos.blogspot.com/2010/08/how-to-get-rid-of-white-margin-in.html

% get the current axes
ax = get(h, 'CurrentAxes');
set(ax,'Units','normalized');

% make it tight
ti = get(ax,'TightInset');
set(ax,'Position',[ti(1) ti(2) 1-ti(3)-ti(1) 1-ti(4)-ti(2)]);

% adjust the papersize
set(ax,'units','centimeters');
pos = get(ax,'Position');
ti = get(ax,'TightInset');
set(h, 'PaperUnits','centimeters');
set(h, 'PaperSize', [pos(3)+ti(1)+ti(3) pos(4)+ti(2)+ti(4)]);
set(h, 'PaperPositionMode', 'manual');
set(h, 'PaperPosition',[0 0  pos(3)+ti(1)+ti(3) pos(4)+ti(2)+ti(4)]);
    
saveas(h,[outfilename '.pdf']);
end

function [pretax_income,mtr] = load_steuerle_mtrs()

global DATADIR;

% Import the data
[~, ~, raw] = xlsread([DATADIR 'input/MTR Calculator 2015_lockwood.xlsx'],'Chart Values');
raw = raw(5:104,[25,28]);

% Create output variable
data = reshape([raw{:}],size(raw));

% Allocate imported array to column variable names
pretax_income = data(:,1);
mtr = data(:,2);

% Clear temporary variables
clearvars data raw;

end