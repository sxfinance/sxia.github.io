# Input data Readme

* cps_00012.dat 
    * downloaded from IPUMS-CPS on Aug 20, 2015
* MTR Calculator 2015_lockwood.xlsx 
    * Source for figure in Gene-Steuerle-Testimony-062515-HR-5.pdf
    * xlsx file obtained via email from Caleb Quakenbush on May 9, 2017
* Notes on beta estimates.xlsx
    * Constructed from lit review described in paper
* cps_00017.dta
    * downloaded from IPUMS-CPS on May 24, 2017
