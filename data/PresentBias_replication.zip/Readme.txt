# Readme

This is the replication folder for "Optimal Income Taxation with Present Bias" by Benjamin B. Lockwood.
It has been uploaded to the AEA Data and Code Repository, where it has Project ID openicpsr-117264. 
A full list of folder contents is below. 
All `.dta` and `.do` files are to be used with Stata, while `.m` and `.mat` files are to be used with Matlab. 
Contents of `/dropbox/data/intermediate/` are generated during execution.
See `/dropbox/data/input/Readme.txt` for sources of all original data files. 

To generate results for the paper, set the folder containing this Readme as the working directory, then run the following files (in this order) from `github/analysis/code/`:

1. `set_globals.do`
2. `build_cps.do`
3. `compute_mswws.do`
4. `simulations.m` (in this case, set this script's containing directory as the working directory)

Then compile the paper and appendix in `github/writeup/`.

## Complete folder contents list.

Where relevant, files are followed by a description of the file's purpose and format. For sourcing information, see the Readme.txt in the containing directory.


```
Readme.txt	
Readme.pdf

/dropbox:
	/data:
		/input:
			cps_00012.dat: CPS data for primary simulations (read in by Stata). 
			cps_00017.dta: CPS data for inverse optimum procedure (Stata). 
			Gene-Steuerle-Testimony-062515-HR-5.pdf: source of gray points in Fig 1.
			Notes on beta estimates.xlsx: See Appendix D for sources and description. (Excel)
			MTR Calculator 2015_lockwood.xlsx: see Readme.txt (Excel)
			Readme.txt				

		/intermediate:


/github:
	/analysis:
		/code:
			build_cps.do: formats CPS data for simulations (Stata)
			compute_mswws.do: generates Figure 4 (Stata)
			set_globals.do: sets global directory references (Stata)
			simulations.m: runs primary simulations (Matlab)

		/output:
			/figures: all exported by scripts
				full_sims.pdf
				mswws_by_income.pdf		
				opt_tax_sims.pdf		
				opt_tax_sims_with_goda.pdf

	/writeup: Main paper and appendix files. Compile with LaTeX (repeatedly, for x-refs)
		appendix.tex	
		appendix.pdf	
		paper.tex
		paper.pdf

		/bib:
			aea.bst		
			library.bib

		/resources:
			Readme.txt		
			beta_vs_income.pdf
```
